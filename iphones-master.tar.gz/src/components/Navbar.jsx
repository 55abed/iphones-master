import React, { useEffect, useState } from 'react'
const Navbar = () => {
const [user, setUser] = useState(null);


useEffect(()=>{
    const loggedUser=JSON.parse(localStorage.getItem("user"));   setUser(loggedUser)
},[]);


const logout=()=>{
    localStorage.removeItem("user");
    setUser(null)
}
 

    return (
        <section className="row">
            <div className="col-md-12">
                {/* <!-- a nav with navbar content  --> */}
                <nav className="navbar navbar-expand-md bg-dark">
                    {/* <img src="images/logo.jpg" alt="" style={{ height: 50, width: 40 ,objectFit:"fill" }} /> */}
                    <a href="home" className=" navbar-brand text-danger">Iphones</a>
                    <button className="navbar-toggler" data-bs-target="#navbarcollapse" data-bs-toggle="collapse">
                        {/* <span className="nav-link">welcome{user.email}</span> */}
                    </button>
                    <div className="collapse navbar-collapse" id="navbarcollapse">
                        <div className="navbar-nav">
                            <a href="/home" className="nav-link text-light">Home</a>
                            <a href="/addproducts" className="nav-link text-light">Add products</a>
                            </div>
                            {user ? (
                                <>
                                    <span className="nav-link">welcome{user.username}</span>
                                    <button onClick={logout} className='btn btn-danger'>logout</button>
                                </>
                            ) : (
                                <>
                                <div style={{marginLeft:'800px',display:'flex',gap:'15px'}}>
                                    <a href="/signin" className="nav-link text-light">sign in</a>
                                    <a href="/signup" className="nav-link text-light ">sign up</a>
                                </div>
                                </>
                            )}
                            {/* <!-- a division containg the links --> */}



                    </div>
                </nav>
            </div>
        </section>
    )
}

export default Navbar